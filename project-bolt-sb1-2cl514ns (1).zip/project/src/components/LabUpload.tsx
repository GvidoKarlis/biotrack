import React, { useState } from 'react';
import { Upload, FileText, CheckCircle, AlertCircle, ArrowLeft, Camera } from 'lucide-react';

interface LabUploadProps {
  onComplete: () => void;
}

export function LabUpload({ onComplete }: LabUploadProps) {
  const [uploadStep, setUploadStep] = useState(1);
  const [files, setFiles] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(event.target.files || []);
    setFiles(prev => [...prev, ...selectedFiles]);
  };

  const processResults = async () => {
    setIsProcessing(true);
    // Simulate processing time
    setTimeout(() => {
      setIsProcessing(false);
      setUploadStep(3);
    }, 3000);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <button
          onClick={() => window.history.back()}
          className="flex items-center text-blue-600 hover:text-blue-700 mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </button>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Upload Lab Results</h1>
        <p className="text-gray-600">Upload your blood work to get personalized health insights and biological age analysis</p>
      </div>

      {uploadStep === 1 && (
        <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-8">
          <div className="text-center mb-8">
            <div className="bg-blue-100 p-6 rounded-full w-fit mx-auto mb-6">
              <Upload className="h-12 w-12 text-blue-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Upload Your Lab Results</h2>
            <p className="text-gray-600 mb-8">
              Supported formats: PDF, JPG, PNG. Maximum file size: 10MB per file.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <div 
              className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-blue-400 hover:bg-blue-50 transition-all cursor-pointer"
              onClick={() => document.getElementById('file-upload')?.click()}
            >
              <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="font-semibold text-gray-900 mb-2">Upload Files</h3>
              <p className="text-gray-600 text-sm mb-4">Click to browse or drag & drop</p>
              <input
                id="file-upload"
                type="file"
                multiple
                accept=".pdf,.jpg,.jpeg,.png"
                onChange={handleFileUpload}
                className="hidden"
              />
            </div>

            <div 
              className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-green-400 hover:bg-green-50 transition-all cursor-pointer"
            >
              <Camera className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="font-semibold text-gray-900 mb-2">Take Photo</h3>
              <p className="text-gray-600 text-sm mb-4">Use your camera to capture results</p>
            </div>
          </div>

          {files.length > 0 && (
            <div className="mb-8">
              <h3 className="font-semibold text-gray-900 mb-4">Uploaded Files</h3>
              <div className="space-y-3">
                {files.map((file, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <FileText className="h-5 w-5 text-gray-400 mr-3" />
                      <span className="text-gray-900">{file.name}</span>
                    </div>
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="text-center">
            <button
              onClick={() => setUploadStep(2)}
              disabled={files.length === 0}
              className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold disabled:bg-gray-300 disabled:cursor-not-allowed hover:bg-blue-700 transition-colors"
            >
              Continue to Analysis
            </button>
          </div>
        </div>
      )}

      {uploadStep === 2 && (
        <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-8">
          <div className="text-center mb-8">
            <div className="bg-purple-100 p-6 rounded-full w-fit mx-auto mb-6">
              <AlertCircle className="h-12 w-12 text-purple-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Confirm Lab Details</h2>
            <p className="text-gray-600">
              Please verify the information below before we process your results
            </p>
          </div>

          <div className="bg-gray-50 rounded-xl p-6 mb-8">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Lab Date</label>
                <input
                  type="date"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  defaultValue="2024-01-15"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Lab Facility</label>
                <input
                  type="text"
                  placeholder="Quest Diagnostics"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Test Type</label>
                <select className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                  <option>Comprehensive Metabolic Panel</option>
                  <option>Lipid Panel</option>
                  <option>Vitamin Panel</option>
                  <option>Hormone Panel</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Fasting Status</label>
                <select className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                  <option>Fasting (12+ hours)</option>
                  <option>Non-fasting</option>
                  <option>Unknown</option>
                </select>
              </div>
            </div>
          </div>

          <div className="text-center">
            <button
              onClick={processResults}
              disabled={isProcessing}
              className="bg-purple-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-purple-700 transition-colors disabled:opacity-50"
            >
              {isProcessing ? 'Processing Results...' : 'Process Lab Results'}
            </button>
          </div>
        </div>
      )}

      {uploadStep === 3 && (
        <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-8">
          <div className="text-center mb-8">
            <div className="bg-green-100 p-6 rounded-full w-fit mx-auto mb-6">
              <CheckCircle className="h-12 w-12 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Results Processed Successfully!</h2>
            <p className="text-gray-600 mb-8">
              Your lab results have been analyzed and your biological age has been calculated.
            </p>
          </div>

          <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-xl p-6 mb-8">
            <h3 className="font-bold text-green-900 mb-4">Key Findings:</h3>
            <ul className="space-y-2 text-green-800">
              <li>✓ Biological age calculated: 28 years (4 years younger than chronological age)</li>
              <li>✓ Vitamin D deficiency detected - supplementation recommended</li>
              <li>✓ Excellent lipid profile - cardiovascular risk is low</li>
              <li>✓ Iron levels slightly below optimal - monitor closely</li>
            </ul>
          </div>

          <div className="text-center">
            <button
              onClick={onComplete}
              className="bg-green-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors mr-4"
            >
              View Full Dashboard
            </button>
            <button className="border border-gray-300 text-gray-700 px-8 py-3 rounded-lg font-semibold hover:bg-gray-50 transition-colors">
              Download Report
            </button>
          </div>
        </div>
      )}
    </div>
  );
}