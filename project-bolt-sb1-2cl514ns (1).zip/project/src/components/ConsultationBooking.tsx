import React, { useState } from 'react';
import { Calendar, Clock, User, Video, MessageCircle, CheckCircle, ArrowRight } from 'lucide-react';

export function ConsultationBooking() {
  const [selectedExpert, setSelectedExpert] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [consultationType, setConsultationType] = useState<'video' | 'chat'>('video');

  const experts = [
    {
      id: 'dr-johnson',
      name: 'Dr. Sarah Johnson',
      title: 'Licensed Physician & Longevity Specialist',
      specialty: 'Anti-Aging Medicine',
      rating: 4.9,
      reviews: 127,
      price: 199,
      experience: '15+ years',
      image: 'https://images.pexels.com/photos/5452293/pexels-photo-5452293.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
      expertise: ['Biological Age Optimization', 'Hormone Therapy', 'Preventive Medicine', 'Lab Interpretation'],
      nextAvailable: 'Today 2:00 PM'
    },
    {
      id: 'nutritionist-maria',
      name: 'Maria Rodriguez, RD',
      title: 'Registered Dietitian & Nutritionist',
      specialty: 'Precision Nutrition',
      rating: 4.8,
      reviews: 203,
      price: 149,
      experience: '12+ years',
      image: 'https://images.pexels.com/photos/6198622/pexels-photo-6198622.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
      expertise: ['Vitamin Deficiency Protocols', 'Personalized Nutrition', 'Supplement Guidance', 'Metabolic Optimization'],
      nextAvailable: 'Tomorrow 10:00 AM'
    },
    {
      id: 'coach-david',
      name: 'David Chen, CPT',
      title: 'Certified Personal Trainer & Health Coach',
      specialty: 'Biohacking & Performance',
      rating: 4.9,
      reviews: 156,
      price: 129,
      experience: '10+ years',
      image: 'https://images.pexels.com/photos/7647013/pexels-photo-7647013.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
      expertise: ['Athletic Performance', 'Recovery Optimization', 'Longevity Training', 'Biomarker Improvement'],
      nextAvailable: 'Today 4:30 PM'
    }
  ];

  const timeSlots = [
    '9:00 AM', '10:00 AM', '11:00 AM', '2:00 PM', '3:00 PM', '4:00 PM', '5:00 PM'
  ];

  const selectedExpertData = experts.find(expert => expert.id === selectedExpert);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Book a Consultation</h1>
        <p className="text-gray-600">Connect with our expert team for personalized health optimization guidance</p>
      </div>

      {/* Expert Selection */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6 mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Choose Your Expert</h2>
        
        <div className="grid lg:grid-cols-1 gap-6">
          {experts.map((expert) => (
            <div
              key={expert.id}
              onClick={() => setSelectedExpert(expert.id)}
              className={`p-6 rounded-xl border-2 cursor-pointer transition-all duration-200 hover:shadow-md ${
                selectedExpert === expert.id 
                  ? 'border-blue-500 bg-blue-50 ring-4 ring-blue-500 ring-opacity-20' 
                  : 'border-gray-200 hover:border-blue-300'
              }`}
            >
              <div className="flex flex-col lg:flex-row lg:items-center gap-6">
                <img
                  src={expert.image}
                  alt={expert.name}
                  className="w-24 h-24 rounded-full object-cover mx-auto lg:mx-0"
                />
                
                <div className="flex-1 text-center lg:text-left">
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between mb-3">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">{expert.name}</h3>
                      <p className="text-blue-600 font-medium">{expert.title}</p>
                    </div>
                    <div className="text-right mt-2 lg:mt-0">
                      <div className="text-2xl font-bold text-gray-900">${expert.price}</div>
                      <div className="text-sm text-gray-600">per session</div>
                    </div>
                  </div>
                  
                  <div className="flex flex-col lg:flex-row lg:items-center gap-4 mb-4">
                    <div className="flex items-center justify-center lg:justify-start">
                      <div className="flex items-center mr-4">
                        {[...Array(5)].map((_, i) => (
                          <CheckCircle key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                        ))}
                        <span className="ml-2 text-sm font-medium">{expert.rating}</span>
                      </div>
                      <span className="text-sm text-gray-600">({expert.reviews} reviews)</span>
                    </div>
                    <div className="text-sm text-gray-600">{expert.experience} experience</div>
                    <div className="text-sm font-medium text-green-600">Next: {expert.nextAvailable}</div>
                  </div>

                  <div className="flex flex-wrap gap-2 justify-center lg:justify-start">
                    {expert.expertise.map((skill, idx) => (
                      <span key={idx} className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm">
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Consultation Details */}
      {selectedExpertData && (
        <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Consultation Details</h2>
          
          {/* Consultation Type */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Consultation Type</h3>
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => setConsultationType('video')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  consultationType === 'video'
                    ? 'border-blue-500 bg-blue-50 text-blue-900'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <Video className="h-6 w-6 mx-auto mb-2" />
                <div className="font-semibold">Video Call</div>
                <div className="text-sm text-gray-600">Face-to-face consultation</div>
              </button>
              
              <button
                onClick={() => setConsultationType('chat')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  consultationType === 'chat'
                    ? 'border-blue-500 bg-blue-50 text-blue-900'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <MessageCircle className="h-6 w-6 mx-auto mb-2" />
                <div className="font-semibold">Text Chat</div>
                <div className="text-sm text-gray-600">Written consultation</div>
              </button>
            </div>
          </div>

          {/* Date Selection */}
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Select Date</h3>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Available Times</h3>
              <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto">
                {timeSlots.map((time) => (
                  <button
                    key={time}
                    onClick={() => setSelectedTime(time)}
                    className={`p-3 rounded-lg border transition-all ${
                      selectedTime === time
                        ? 'border-blue-500 bg-blue-50 text-blue-900'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    {time}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Booking Summary */}
      {selectedExpertData && selectedDate && selectedTime && (
        <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-xl p-6">
          <h3 className="text-xl font-bold text-green-900 mb-4">Booking Summary</h3>
          
          <div className="grid md:grid-cols-2 gap-6 mb-6">
            <div>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="font-medium text-gray-700">Expert:</span>
                  <span className="text-gray-900">{selectedExpertData.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium text-gray-700">Type:</span>
                  <span className="text-gray-900 capitalize">{consultationType} Consultation</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium text-gray-700">Date:</span>
                  <span className="text-gray-900">{new Date(selectedDate).toLocaleDateString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium text-gray-700">Time:</span>
                  <span className="text-gray-900">{selectedTime}</span>
                </div>
              </div>
            </div>

            <div className="border-l border-green-300 pl-6">
              <div className="text-2xl font-bold text-green-900 mb-2">${selectedExpertData.price}</div>
              <div className="text-green-700 text-sm mb-4">60-minute consultation</div>
              <button className="bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors flex items-center">
                Book Consultation
                <ArrowRight className="ml-2 h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}