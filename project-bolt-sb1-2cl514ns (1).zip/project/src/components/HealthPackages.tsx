import React, { useState } from 'react';
import { Heart, Zap, Flame, Shield, Star, CheckCircle, ArrowRight } from 'lucide-react';

export function HealthPackages() {
  const [selectedPackage, setSelectedPackage] = useState<string | null>(null);

  const packages = [
    {
      id: 'essential',
      title: 'Essential Longevity',
      subtitle: 'Perfect for biohacking beginners',
      price: 299,
      originalPrice: 399,
      icon: Shield,
      color: 'blue',
      popular: false,
      features: [
        'Comprehensive metabolic panel',
        'Biological age calculation (PhenoAge)',
        'Basic vitamin deficiency analysis',
        'Digital health dashboard',
        'Basic supplement recommendations',
        '1 nutritionist consultation'
      ],
      testsIncluded: [
        'Complete Blood Count (CBC)',
        'Comprehensive Metabolic Panel',
        'Lipid Profile',
        'Vitamin D, B12, Folate',
        'Thyroid Function (TSH, T3, T4)',
        'HbA1c & Glucose'
      ]
    },
    {
      id: 'premium',
      title: 'Premium Optimization',
      subtitle: 'Most comprehensive health analysis',
      price: 599,
      originalPrice: 799,
      icon: Star,
      color: 'purple',
      popular: true,
      features: [
        'Everything in Essential +',
        'Advanced aging biomarkers',
        'Comprehensive vitamin & mineral panel',
        'Hormone optimization analysis',
        'Inflammatory markers',
        '3 expert consultations',
        'Personalized supplement protocol',
        'Quarterly progress tracking'
      ],
      testsIncluded: [
        'All Essential tests +',
        'Advanced Lipid Profile',
        'Complete Vitamin Panel (A, B, C, D, E, K)',
        'Mineral Panel (Magnesium, Zinc, Iron)',
        'Hormone Panel (Testosterone, Cortisol, DHEA)',
        'Inflammatory Markers (CRP, IL-6)',
        'Oxidative Stress Markers'
      ]
    },
    {
      id: 'athlete',
      title: 'Athletic Performance',
      subtitle: 'Optimized for fitness enthusiasts',
      price: 449,
      originalPrice: 599,
      icon: Zap,
      color: 'green',
      popular: false,
      features: [
        'Performance-focused biomarkers',
        'Recovery & endurance metrics',
        'Muscle health indicators',
        'Energy metabolism analysis',
        'Sports nutrition guidance',
        '2 fitness coach consultations',
        'Workout optimization plan'
      ],
      testsIncluded: [
        'Complete Blood Count',
        'Metabolic Panel',
        'Creatine Kinase',
        'Lactate Dehydrogenase',
        'B-Vitamins Complex',
        'Iron Studies',
        'Protein Markers'
      ]
    },
    {
      id: 'cardio',
      title: 'Cardiovascular Health',
      subtitle: 'Heart health optimization',
      price: 379,
      originalPrice: 499,
      icon: Heart,
      color: 'red',
      popular: false,
      features: [
        'Advanced cardiac risk assessment',
        'Cholesterol subfractions',
        'Blood pressure optimization',
        'Arterial health markers',
        'Cardiac-specific nutrition plan',
        '2 cardiologist consultations',
        'Heart health monitoring'
      ],
      testsIncluded: [
        'Advanced Lipid Profile',
        'Apolipoprotein A1 & B',
        'Lipoprotein(a)',
        'C-Reactive Protein',
        'Homocysteine',
        'Fibrinogen',
        'NT-proBNP'
      ]
    }
  ];

  const getColorClasses = (color: string, selected: boolean = false) => {
    const base = selected ? 'ring-4 ring-opacity-50' : '';
    switch (color) {
      case 'blue':
        return `${base} ${selected ? 'ring-blue-500 border-blue-500' : 'border-blue-200 hover:border-blue-300'}`;
      case 'purple':
        return `${base} ${selected ? 'ring-purple-500 border-purple-500' : 'border-purple-200 hover:border-purple-300'}`;
      case 'green':
        return `${base} ${selected ? 'ring-green-500 border-green-500' : 'border-green-200 hover:border-green-300'}`;
      case 'red':
        return `${base} ${selected ? 'ring-red-500 border-red-500' : 'border-red-200 hover:border-red-300'}`;
      default:
        return `${base} border-gray-200 hover:border-gray-300`;
    }
  };

  const getIconColor = (color: string) => {
    switch (color) {
      case 'blue': return 'text-blue-600 bg-blue-100';
      case 'purple': return 'text-purple-600 bg-purple-100';
      case 'green': return 'text-green-600 bg-green-100';
      case 'red': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getButtonColor = (color: string) => {
    switch (color) {
      case 'blue': return 'bg-blue-600 hover:bg-blue-700';
      case 'purple': return 'bg-purple-600 hover:bg-purple-700';
      case 'green': return 'bg-green-600 hover:bg-green-700';
      case 'red': return 'bg-red-600 hover:bg-red-700';
      default: return 'bg-gray-600 hover:bg-gray-700';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Health Optimization Packages</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Choose the perfect package for your health optimization journey. All packages include 
          biological age calculation, personalized insights, and expert consultations.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8 mb-12">
        {packages.map((pkg) => {
          const Icon = pkg.icon;
          const isSelected = selectedPackage === pkg.id;
          
          return (
            <div
              key={pkg.id}
              onClick={() => setSelectedPackage(pkg.id)}
              className={`relative bg-white rounded-2xl border-2 p-8 cursor-pointer transition-all duration-300 hover:shadow-xl ${getColorClasses(pkg.color, isSelected)}`}
            >
              {pkg.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-2 rounded-full text-sm font-semibold">
                    Most Popular
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between mb-6">
                <div className={`p-4 rounded-xl ${getIconColor(pkg.color)}`}>
                  <Icon className="h-8 w-8" />
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold text-gray-900">${pkg.price}</div>
                  <div className="text-sm text-gray-500 line-through">${pkg.originalPrice}</div>
                </div>
              </div>

              <div className="mb-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{pkg.title}</h3>
                <p className="text-gray-600 mb-4">{pkg.subtitle}</p>
              </div>

              <div className="mb-6">
                <h4 className="font-semibold text-gray-900 mb-3">Package Features:</h4>
                <ul className="space-y-2">
                  {pkg.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center text-sm text-gray-700">
                      <CheckCircle className="h-4 w-4 text-green-600 mr-3 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mb-8">
                <h4 className="font-semibold text-gray-900 mb-3">Tests Included:</h4>
                <div className="grid grid-cols-1 gap-1">
                  {pkg.testsIncluded.map((test, idx) => (
                    <div key={idx} className="text-sm text-gray-600 bg-gray-50 px-3 py-1 rounded">
                      {test}
                    </div>
                  ))}
                </div>
              </div>

              <button className={`w-full text-white px-6 py-4 rounded-xl font-semibold transition-colors flex items-center justify-center ${getButtonColor(pkg.color)}`}>
                Choose Package
                <ArrowRight className="ml-2 h-5 w-5" />
              </button>
            </div>
          );
        })}
      </div>

      {/* Additional Information */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-2xl p-8">
        <div className="text-center mb-8">
          <Flame className="h-12 w-12 text-orange-600 mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-gray-900 mb-4">Why Choose VitaLogiQ?</h3>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="bg-white p-4 rounded-xl shadow-md mb-4">
              <Shield className="h-8 w-8 text-blue-600 mx-auto" />
            </div>
            <h4 className="font-semibold text-gray-900 mb-2">Medical Grade Analysis</h4>
            <p className="text-gray-600 text-sm">CLIA-certified labs and physician-reviewed results</p>
          </div>

          <div className="text-center">
            <div className="bg-white p-4 rounded-xl shadow-md mb-4">
              <Star className="h-8 w-8 text-purple-600 mx-auto" />
            </div>
            <h4 className="font-semibold text-gray-900 mb-2">Expert Care Team</h4>
            <p className="text-gray-600 text-sm">Licensed physicians, nutritionists, and health coaches</p>
          </div>

          <div className="text-center">
            <div className="bg-white p-4 rounded-xl shadow-md mb-4">
              <Zap className="h-8 w-8 text-green-600 mx-auto" />
            </div>
            <h4 className="font-semibold text-gray-900 mb-2">Actionable Insights</h4>
            <p className="text-gray-600 text-sm">Personalized protocols based on your unique biology</p>
          </div>
        </div>
      </div>
    </div>
  );
}