import React from 'react';
import { Activity, Home, Upload, Package, Calendar, TrendingUp, MessageCircle, Globe } from 'lucide-react';

interface NavigationProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
  language: 'en' | 'lv';
  onLanguageChange: (language: 'en' | 'lv') => void;
}

export function Navigation({ activeSection, onSectionChange, language, onLanguageChange }: NavigationProps) {

  const navItems = [
    { id: 'hero', label: 'Home', icon: Home },
    { id: 'dashboard', label: 'Dashboard', icon: Activity },
    { id: 'lab-upload', label: 'Lab Upload', icon: Upload },
    { id: 'packages', label: 'Packages', icon: Package },
    { id: 'consultations', label: 'Consultations', icon: Calendar },
    { id: 'progress', label: 'Progress', icon: TrendingUp },
  ];

  return (
    <nav className="bg-white shadow-lg border-b border-blue-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Activity className="h-8 w-8 text-blue-600 mr-3" />
            <span className="text-2xl font-bold text-gray-900">VitaLogiQ</span>
            <span className="ml-2 text-sm text-blue-600 font-medium">Medical</span>
          </div>
          
          <div className="flex space-x-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => onSectionChange(item.id)}
                  className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
                    activeSection === item.id
                      ? 'bg-blue-100 text-blue-700 shadow-sm'
                      : 'text-gray-600 hover:text-blue-600 hover:bg-gray-50'
                  }`}
                >
                  <Icon className="h-4 w-4 mr-2" />
                  <span className="hidden sm:inline">{item.label}</span>
                </button>
              );
            })}
          </div>

          <div className="flex items-center space-x-4">
            <div className="relative">
              <button 
                onClick={() => onLanguageChange(language === 'en' ? 'lv' : 'en')}
                className="flex items-center p-2 text-gray-600 hover:text-blue-600 hover:bg-gray-50 rounded-md transition-colors"
                title="Switch Language"
              >
                <Globe className="h-4 w-4 mr-1" />
                <span className="text-sm font-medium">{language === 'en' ? 'EN' : 'LV'}</span>
              </button>
            </div>
            <button className="p-2 text-gray-600 hover:text-blue-600 hover:bg-gray-50 rounded-md transition-colors">
              <MessageCircle className="h-5 w-5" />
            </button>
            <button className="bg-blue-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-blue-700 transition-colors">
              Upgrade to Pro
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}