import React from 'react';
import { TrendingUp, Target, Award, Calendar, CheckCircle, Clock, Star } from 'lucide-react';

export function ProgressTracking() {
  const goals = [
    {
      id: 1,
      title: 'Reduce Biological Age',
      target: 'Achieve 25 years biological age',
      current: 28,
      target_value: 25,
      progress: 60,
      deadline: '2024-06-30',
      status: 'on-track',
      icon: TrendingUp,
      color: 'blue'
    },
    {
      id: 2,
      title: 'Optimize Vitamin D',
      target: 'Reach optimal level (40 ng/mL)',
      current: 18,
      target_value: 40,
      progress: 45,
      deadline: '2024-03-15',
      status: 'needs-attention',
      icon: Target,
      color: 'yellow'
    },
    {
      id: 3,
      title: 'Improve Sleep Quality',
      target: '8 hours of quality sleep',
      current: 6.5,
      target_value: 8,
      progress: 81,
      deadline: '2024-04-01',
      status: 'on-track',
      icon: Clock,
      color: 'green'
    }
  ];

  const achievements = [
    {
      title: 'First Lab Upload',
      description: 'Uploaded your first comprehensive lab results',
      date: '2024-01-15',
      points: 100,
      icon: CheckCircle,
      color: 'blue'
    },
    {
      title: 'Vitamin D Improvement',
      description: 'Increased Vitamin D levels by 25%',
      date: '2024-01-28',
      points: 250,
      icon: TrendingUp,
      color: 'green'
    },
    {
      title: 'Consistency Master',
      description: 'Followed supplement protocol for 30 days',
      date: '2024-02-01',
      points: 300,
      icon: Star,
      color: 'purple'
    }
  ];

  const weeklyProgress = [
    { week: 'Week 1', biologicalAge: 32, vitaminD: 15, sleepHours: 6.2 },
    { week: 'Week 2', biologicalAge: 31.5, vitaminD: 16, sleepHours: 6.4 },
    { week: 'Week 3', biologicalAge: 31, vitaminD: 17, sleepHours: 6.6 },
    { week: 'Week 4', biologicalAge: 30.5, vitaminD: 18, sleepHours: 6.8 },
    { week: 'Current', biologicalAge: 28, vitaminD: 18, sleepHours: 6.5 }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'on-track': return 'bg-green-100 text-green-800 border-green-200';
      case 'needs-attention': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'behind': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getIconColor = (color: string) => {
    switch (color) {
      case 'blue': return 'text-blue-600 bg-blue-100';
      case 'green': return 'text-green-600 bg-green-100';
      case 'yellow': return 'text-yellow-600 bg-yellow-100';
      case 'purple': return 'text-purple-600 bg-purple-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Progress Tracking</h1>
        <p className="text-gray-600">Monitor your health optimization journey and celebrate milestones</p>
      </div>

      {/* Current Goals */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6 mb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Current Health Goals</h2>
          <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
            Set New Goal
          </button>
        </div>

        <div className="space-y-6">
          {goals.map((goal) => {
            const Icon = goal.icon;
            return (
              <div key={goal.id} className="border border-gray-200 rounded-xl p-6 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-start space-x-4">
                    <div className={`p-3 rounded-lg ${getIconColor(goal.color)}`}>
                      <Icon className="h-6 w-6" />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-gray-900 mb-1">{goal.title}</h3>
                      <p className="text-gray-600 mb-2">{goal.target}</p>
                      <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(goal.status)}`}>
                        {goal.status === 'on-track' && <CheckCircle className="h-4 w-4 mr-1" />}
                        {goal.status.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-gray-900">
                      {goal.current}
                      <span className="text-base text-gray-600 ml-1">/ {goal.target_value}</span>
                    </div>
                    <div className="text-sm text-gray-500">Deadline: {new Date(goal.deadline).toLocaleDateString()}</div>
                  </div>
                </div>

                <div className="mb-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-gray-700">Progress</span>
                    <span className="text-sm font-medium text-gray-900">{goal.progress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div 
                      className={`h-3 rounded-full ${
                        goal.color === 'blue' ? 'bg-blue-500' : 
                        goal.color === 'green' ? 'bg-green-500' : 
                        goal.color === 'yellow' ? 'bg-yellow-500' : 'bg-gray-500'
                      }`}
                      style={{ width: `${goal.progress}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Progress Chart */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-lg border border-gray-100 p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-6">Weekly Progress Trends</h3>
          
          <div className="space-y-4">
            <div className="grid grid-cols-4 gap-4 text-sm font-medium text-gray-600 pb-2 border-b">
              <div>Period</div>
              <div>Biological Age</div>
              <div>Vitamin D</div>
              <div>Sleep Hours</div>
            </div>
            
            {weeklyProgress.map((week, index) => (
              <div key={index} className={`grid grid-cols-4 gap-4 p-3 rounded-lg ${index === weeklyProgress.length - 1 ? 'bg-blue-50 border border-blue-200' : 'hover:bg-gray-50'}`}>
                <div className="font-medium text-gray-900">{week.week}</div>
                <div className="flex items-center">
                  <span className="font-semibold">{week.biologicalAge}</span>
                  <span className="text-sm text-gray-500 ml-1">years</span>
                </div>
                <div className="flex items-center">
                  <span className="font-semibold">{week.vitaminD}</span>
                  <span className="text-sm text-gray-500 ml-1">ng/mL</span>
                </div>
                <div className="flex items-center">
                  <span className="font-semibold">{week.sleepHours}</span>
                  <span className="text-sm text-gray-500 ml-1">hrs</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Achievements */}
        <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-gray-900">Recent Achievements</h3>
            <Award className="h-6 w-6 text-yellow-500" />
          </div>

          <div className="space-y-4">
            {achievements.map((achievement, index) => {
              const Icon = achievement.icon;
              return (
                <div key={index} className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg">
                  <div className={`p-2 rounded-lg ${getIconColor(achievement.color)}`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 mb-1">{achievement.title}</h4>
                    <p className="text-sm text-gray-600 mb-2">{achievement.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-500">{achievement.date}</span>
                      <span className="text-sm font-medium text-yellow-600">+{achievement.points} pts</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-6 p-4 bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200 rounded-lg text-center">
            <h4 className="font-bold text-purple-900 mb-2">Total Points</h4>
            <div className="text-3xl font-bold text-purple-900">650</div>
            <p className="text-sm text-purple-700">Keep going for premium rewards!</p>
          </div>
        </div>
      </div>
    </div>
  );
}