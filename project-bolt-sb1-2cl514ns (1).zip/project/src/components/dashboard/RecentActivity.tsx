import React from 'react';
import { Clock, Upload, Calendar, CheckCircle, AlertCircle } from 'lucide-react';

export function RecentActivity() {
  const activities = [
    {
      type: 'lab_upload',
      title: 'Lab Results Uploaded',
      description: 'Comprehensive metabolic panel processed',
      time: '2 hours ago',
      icon: Upload,
      color: 'blue'
    },
    {
      type: 'consultation',
      title: 'Consultation Completed',
      description: 'Dr. Sarah Johnson - Vitamin D deficiency discussed',
      time: '1 day ago',
      icon: CheckCircle,
      color: 'green'
    },
    {
      type: 'alert',
      title: 'Health Alert',
      description: 'Iron levels require attention',
      time: '2 days ago',
      icon: AlertCircle,
      color: 'yellow'
    },
    {
      type: 'appointment',
      title: 'Upcoming Consultation',
      description: 'Nutritionist session in 3 days',
      time: '3 days ago',
      icon: Calendar,
      color: 'purple'
    }
  ];

  const getColorClasses = (color: string) => {
    switch (color) {
      case 'blue':
        return 'bg-blue-100 text-blue-600';
      case 'green':
        return 'bg-green-100 text-green-600';
      case 'yellow':
        return 'bg-yellow-100 text-yellow-600';
      case 'purple':
        return 'bg-purple-100 text-purple-600';
      default:
        return 'bg-gray-100 text-gray-600';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-gray-900">Recent Activity</h3>
        <Clock className="h-5 w-5 text-gray-400" />
      </div>
      
      <div className="space-y-4">
        {activities.map((activity, index) => {
          const Icon = activity.icon;
          return (
            <div key={index} className="flex items-start space-x-4 p-3 hover:bg-gray-50 rounded-lg transition-colors">
              <div className={`p-2 rounded-lg ${getColorClasses(activity.color)}`}>
                <Icon className="h-4 w-4" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-gray-900 text-sm">{activity.title}</p>
                <p className="text-sm text-gray-600 truncate">{activity.description}</p>
                <p className="text-xs text-gray-400 mt-1">{activity.time}</p>
              </div>
            </div>
          );
        })}
      </div>

      <button className="w-full mt-4 text-center text-blue-600 font-medium text-sm hover:text-blue-700 transition-colors">
        View All Activity
      </button>
    </div>
  );
}