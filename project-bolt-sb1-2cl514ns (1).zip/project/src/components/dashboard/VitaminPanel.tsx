import React from 'react';
import { AlertTriangle, CheckCircle, Minus, ShoppingBag } from 'lucide-react';

export function VitaminPanel() {
  const vitamins = [
    { name: 'Vitamin D', level: 18, optimal: 30, unit: 'ng/mL', status: 'low', color: 'red' },
    { name: 'B12', level: 450, optimal: 300, unit: 'pg/mL', status: 'optimal', color: 'green' },
    { name: 'Iron', level: 85, optimal: 100, unit: 'μg/dL', status: 'borderline', color: 'yellow' },
    { name: 'Magnesium', level: 2.1, optimal: 2.0, unit: 'mg/dL', status: 'optimal', color: 'green' },
    { name: 'Folate', level: 4.2, optimal: 4.0, unit: 'ng/mL', status: 'optimal', color: 'green' },
    { name: 'Omega-3', level: 3.8, optimal: 4.0, unit: '%', status: 'borderline', color: 'yellow' },
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'low':
        return <AlertTriangle className="h-5 w-5 text-red-600" />;
      case 'optimal':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      default:
        return <Minus className="h-5 w-5 text-yellow-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'low':
        return 'border-red-200 bg-red-50';
      case 'optimal':
        return 'border-green-200 bg-green-50';
      default:
        return 'border-yellow-200 bg-yellow-50';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Vitamin & Nutrient Analysis</h2>
        <button className="flex items-center bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
          <ShoppingBag className="h-4 w-4 mr-2" />
          Order Supplements
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        {vitamins.map((vitamin, index) => (
          <div key={index} className={`p-4 rounded-xl border ${getStatusColor(vitamin.status)} hover:shadow-md transition-all duration-200`}>
            <div className="flex items-center justify-between mb-3">
              <span className="font-semibold text-gray-900">{vitamin.name}</span>
              {getStatusIcon(vitamin.status)}
            </div>
            <div className="text-2xl font-bold text-gray-900 mb-1">
              {vitamin.level} <span className="text-sm font-normal text-gray-600">{vitamin.unit}</span>
            </div>
            <div className="text-sm text-gray-600 mb-3">
              Optimal: {vitamin.optimal} {vitamin.unit}
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className={`h-2 rounded-full ${vitamin.status === 'low' ? 'bg-red-500' : vitamin.status === 'optimal' ? 'bg-green-500' : 'bg-yellow-500'}`}
                style={{ width: `${Math.min((vitamin.level / vitamin.optimal) * 100, 100)}%` }}
              ></div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
        <div className="flex items-center mb-2">
          <AlertTriangle className="h-5 w-5 text-amber-600 mr-2" />
          <span className="font-semibold text-amber-900">Recommendations</span>
        </div>
        <p className="text-amber-800 text-sm">
          Your Vitamin D levels are below optimal range. Consider supplementation and increased sun exposure. 
          Schedule a consultation with our nutritionist for a personalized protocol.
        </p>
      </div>
    </div>
  );
}