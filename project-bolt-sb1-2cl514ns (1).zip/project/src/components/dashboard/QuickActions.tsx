import React from 'react';
import { Upload, Calendar, ShoppingBag, MessageCircle, FileText, Users } from 'lucide-react';

export function QuickActions() {
  const actions = [
    { icon: Upload, label: 'Upload Labs', color: 'blue', description: 'Add new lab results' },
    { icon: Calendar, label: 'Book Consultation', color: 'green', description: 'Schedule with expert' },
    { icon: ShoppingBag, label: 'Order Supplements', color: 'purple', description: 'Personalized vitamins' },
    { icon: MessageCircle, label: 'Chat with Team', color: 'indigo', description: '24/7 clinical support' },
    { icon: FileText, label: 'View Reports', color: 'orange', description: 'Download insights' },
    { icon: Users, label: 'Telemedicine', color: 'teal', description: 'Video consultation' }
  ];

  const getColorClasses = (color: string) => {
    switch (color) {
      case 'blue':
        return 'bg-blue-100 text-blue-600 hover:bg-blue-200';
      case 'green':
        return 'bg-green-100 text-green-600 hover:bg-green-200';
      case 'purple':
        return 'bg-purple-100 text-purple-600 hover:bg-purple-200';
      case 'indigo':
        return 'bg-indigo-100 text-indigo-600 hover:bg-indigo-200';
      case 'orange':
        return 'bg-orange-100 text-orange-600 hover:bg-orange-200';
      case 'teal':
        return 'bg-teal-100 text-teal-600 hover:bg-teal-200';
      default:
        return 'bg-gray-100 text-gray-600 hover:bg-gray-200';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
      <h3 className="text-xl font-bold text-gray-900 mb-6">Quick Actions</h3>
      
      <div className="grid grid-cols-2 gap-3">
        {actions.map((action, index) => {
          const Icon = action.icon;
          return (
            <button
              key={index}
              className={`p-4 rounded-xl border-2 border-transparent hover:border-gray-200 transition-all duration-200 text-left group ${getColorClasses(action.color)}`}
            >
              <div className="flex items-center mb-2">
                <Icon className="h-5 w-5 mr-2" />
                <span className="font-medium text-gray-900 text-sm">{action.label}</span>
              </div>
              <p className="text-xs text-gray-600 group-hover:text-gray-700">{action.description}</p>
            </button>
          );
        })}
      </div>
    </div>
  );
}