import React from 'react';
import { User, TrendingUp, Award, Clock } from 'lucide-react';

export function DigitalTwin() {
  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-gray-900">Digital Twin</h3>
        <div className="bg-blue-100 p-2 rounded-lg">
          <User className="h-5 w-5 text-blue-600" />
        </div>
      </div>

      {/* Avatar and Basic Info */}
      <div className="text-center mb-6">
        <div className="w-24 h-24 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full mx-auto mb-4 flex items-center justify-center">
          <User className="h-12 w-12 text-white" />
        </div>
        <h4 className="font-semibold text-gray-900 mb-1">Health Profile</h4>
        <p className="text-sm text-gray-600">Biohacker Enthusiast</p>
      </div>

      {/* Key Stats */}
      <div className="space-y-4">
        <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200">
          <div className="flex items-center">
            <TrendingUp className="h-4 w-4 text-green-600 mr-2" />
            <span className="text-sm font-medium text-green-900">Health Score</span>
          </div>
          <span className="text-lg font-bold text-green-900">87/100</span>
        </div>

        <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-center">
            <Award className="h-4 w-4 text-blue-600 mr-2" />
            <span className="text-sm font-medium text-blue-900">Longevity Rank</span>
          </div>
          <span className="text-lg font-bold text-blue-900">Top 15%</span>
        </div>

        <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg border border-purple-200">
          <div className="flex items-center">
            <Clock className="h-4 w-4 text-purple-600 mr-2" />
            <span className="text-sm font-medium text-purple-900">Years Gained</span>
          </div>
          <span className="text-lg font-bold text-purple-900">+4.2</span>
        </div>
      </div>

      {/* Recent Achievement */}
      <div className="mt-6 p-4 bg-gradient-to-r from-yellow-50 to-orange-50 border border-yellow-200 rounded-xl">
        <div className="flex items-center mb-2">
          <Award className="h-5 w-5 text-yellow-600 mr-2" />
          <span className="font-semibold text-yellow-900">Recent Achievement</span>
        </div>
        <p className="text-sm text-yellow-800">
          Improved biological age by 6 months in the last quarter!
        </p>
      </div>
    </div>
  );
}