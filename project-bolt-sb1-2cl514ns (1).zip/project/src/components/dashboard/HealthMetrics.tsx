import React from 'react';
import { Heart, Zap, Scale, Moon } from 'lucide-react';

export function HealthMetrics() {
  const metrics = [
    {
      title: 'Cardiovascular Risk',
      value: 'Low',
      score: 15,
      icon: Heart,
      color: 'green',
      description: 'Excellent lipid profile'
    },
    {
      title: 'Energy Level',
      value: 'High',
      score: 85,
      icon: Zap,
      color: 'blue',
      description: 'Optimal mitochondrial function'
    },
    {
      title: 'Metabolic Health',
      value: 'Good',
      score: 72,
      icon: Scale,
      color: 'green',
      description: 'Healthy glucose metabolism'
    },
    {
      title: 'Sleep Quality',
      value: 'Fair',
      score: 68,
      icon: Moon,
      color: 'yellow',
      description: 'Room for improvement'
    }
  ];

  const getColorClasses = (color: string) => {
    switch (color) {
      case 'green':
        return { bg: 'bg-green-50', border: 'border-green-200', icon: 'text-green-600', text: 'text-green-900' };
      case 'blue':
        return { bg: 'bg-blue-50', border: 'border-blue-200', icon: 'text-blue-600', text: 'text-blue-900' };
      case 'yellow':
        return { bg: 'bg-yellow-50', border: 'border-yellow-200', icon: 'text-yellow-600', text: 'text-yellow-900' };
      default:
        return { bg: 'bg-gray-50', border: 'border-gray-200', icon: 'text-gray-600', text: 'text-gray-900' };
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Health Metrics Overview</h2>
        <span className="text-sm text-gray-500">Updated 2 hours ago</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {metrics.map((metric, index) => {
          const colors = getColorClasses(metric.color);
          const Icon = metric.icon;
          
          return (
            <div key={index} className={`p-6 rounded-xl border ${colors.bg} ${colors.border} hover:shadow-md transition-all duration-200`}>
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg bg-white shadow-sm`}>
                  <Icon className={`h-6 w-6 ${colors.icon}`} />
                </div>
                <div className="text-right">
                  <div className={`text-2xl font-bold ${colors.text}`}>{metric.value}</div>
                  <div className="text-sm text-gray-600">{metric.score}/100</div>
                </div>
              </div>
              
              <h3 className="font-semibold text-gray-900 mb-2">{metric.title}</h3>
              <p className="text-sm text-gray-600 mb-3">{metric.description}</p>
              
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full ${metric.color === 'green' ? 'bg-green-500' : metric.color === 'blue' ? 'bg-blue-500' : 'bg-yellow-500'}`}
                  style={{ width: `${metric.score}%` }}
                ></div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}