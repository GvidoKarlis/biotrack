import React from 'react';
import { TrendingDown, TrendingUp, Calendar, Target } from 'lucide-react';

export function BiologicalAge() {
  const biologicalAge = 28;
  const chronologicalAge = 32;
  const agingSpeed = 0.87;
  const improvement = chronologicalAge - biologicalAge;

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Biological Age Analysis</h2>
        <div className="bg-green-100 p-2 rounded-lg">
          <TrendingDown className="h-6 w-6 text-green-600" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="text-center p-6 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl border border-blue-200">
          <Calendar className="h-8 w-8 text-blue-600 mx-auto mb-3" />
          <div className="text-3xl font-bold text-blue-900 mb-1">{chronologicalAge}</div>
          <div className="text-sm text-blue-700 font-medium">Chronological Age</div>
        </div>

        <div className="text-center p-6 bg-gradient-to-br from-green-50 to-green-100 rounded-xl border border-green-200">
          <Target className="h-8 w-8 text-green-600 mx-auto mb-3" />
          <div className="text-3xl font-bold text-green-900 mb-1">{biologicalAge}</div>
          <div className="text-sm text-green-700 font-medium">Biological Age</div>
        </div>

        <div className="text-center p-6 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl border border-purple-200">
          <TrendingUp className="h-8 w-8 text-purple-600 mx-auto mb-3" />
          <div className="text-3xl font-bold text-purple-900 mb-1">{agingSpeed.toFixed(2)}x</div>
          <div className="text-sm text-purple-700 font-medium">Aging Speed</div>
        </div>
      </div>

      <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-xl p-6">
        <div className="flex items-center mb-4">
          <TrendingDown className="h-6 w-6 text-green-600 mr-3" />
          <span className="text-lg font-semibold text-green-900">Excellent Progress!</span>
        </div>
        <p className="text-green-800 mb-4">
          Your biological age is <span className="font-bold text-2xl">{improvement} years younger</span> than your chronological age. 
          Your aging speed of {agingSpeed}x indicates you're aging slower than average.
        </p>
        <div className="bg-green-600 h-2 rounded-full">
          <div className="bg-green-400 h-2 rounded-full" style={{ width: '75%' }}></div>
        </div>
        <p className="text-sm text-green-700 mt-2">75% improvement from baseline</p>
      </div>
    </div>
  );
}