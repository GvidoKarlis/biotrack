import React, { useState } from 'react';
import { Activity, Shield, Users, TrendingUp, ArrowRight, CheckCircle, MapPin, Calendar, Clock, User } from 'lucide-react';

interface HeroProps {
  onGetStarted: () => void;
  language: 'en' | 'lv';
}

export function Hero({ onGetStarted, language }: HeroProps) {
  const [openFaq, setOpenFaq] = useState<number | null>(0); // First question open by default
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    preferredDate: '',
    preferredTime: '',
    notes: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Home visit reservation:', formData);
    // Handle form submission
    alert('Home visit reservation submitted successfully!');
  };

  const faqData = [
    {
      question: language === 'en' ? "How accurate are the biological age calculations?" : "Cik precīzi ir bioloģiskā vecuma aprēķini?",
      answer: language === 'en' 
        ? "Our biological age calculations use the scientifically validated PhenoAge algorithm, which has been extensively studied and published in peer-reviewed journals. The algorithm analyzes multiple biomarkers to provide an accurate assessment of your biological aging process."
        : "Mūsu bioloģiskā vecuma aprēķini izmanto zinātniski apstiprināto PhenoAge algoritmu, kas ir plaši pētīts un publicēts recenzētajos žurnālos. Algoritms analizē vairākus biomarķierus, lai sniegtu precīzu jūsu bioloģiskā novecošanas procesa novērtējumu."
    },
    {
      question: language === 'en' ? "What biomarkers do you test for?" : "Kādus biomarķierus jūs testējat?",
      answer: language === 'en' 
        ? "We test for a comprehensive panel of biomarkers including glucose, cholesterol, liver enzymes, kidney function markers, inflammatory markers, hormones, vitamins, and minerals. Our complete panel includes over 50 different biomarkers to give you a thorough health assessment."
        : "Mēs testējam visaptverošu biomarķieru paneli, ieskaitot glikozi, holesterīnu, aknu enzīmus, nieru darbības marķierus, iekaisuma marķierus, hormonus, vitamīnus un minerālvielas. Mūsu pilnais panelis ietver vairāk nekā 50 dažādus biomarķierus, lai sniegtu jums rūpīgu veselības novērtējumu."
    },
    {
      question: "Where do I go to get my lab tests?",
      questionLv: "Kur man jāiet, lai veiktu laboratorijas testus?",
      answer: "Currently available labs are in Latvia. You can search here for a location near you.",
      answerLv: "Pašlaik pieejamās laboratorijas ir Latvijā. Jūs varat meklēt šeit atrašanās vietu netālu no jums."
    },
    {
      question: "Do I need a wearable device?",
      questionLv: "Vai man nepieciešama valkājama ierīce?",
      answer: "No, you don't need a wearable device to participate. Wearable just provides us with more data to make more quality predictions and suggestions.",
      answerLv: "Nē, jums nav nepieciešama valkājama ierīce, lai piedalītos. Valkājamā ierīce tikai sniedz mums vairāk datu, lai veiktu kvalitatīvākus prognozes un ieteikumus."
    }
  ];

  const text = {
    en: {
      title: 'Reserve Home Visit',
      subtitle: 'Professional blood draw at your convenience',
      firstName: 'First Name',
      lastName: 'Last Name',
      email: 'Email',
      phone: 'Phone Number',
      address: 'Address',
      preferredDate: 'Preferred Date',
      preferredTime: 'Preferred Time',
      notes: 'Additional Notes',
      submitButton: 'Reserve Home Visit',
      serviceInfo: 'Service available in Riga and surrounding areas • Starting from €89',
      whatToExpect: 'What to Expect',
      expectations: [
        'Certified phlebotomist will arrive at your scheduled time',
        'Professional blood draw equipment and safety protocols',
        'Results processed at CLIA-certified laboratory',
        'Digital results available within 24-48 hours'
      ],
      placeholders: {
        firstName: 'Enter your first name',
        lastName: 'Enter your last name',
        email: 'your.email@example.com',
        phone: '+371 20 123 456',
        address: 'Enter your full address',
        notes: 'Any special instructions or health conditions we should know about...'
      }
    },
    lv: {
      title: 'Rezervē mājas vizīti',
      subtitle: 'Profesionāla asins paņemšana jūsu ērtībai',
      firstName: 'Vārds',
      lastName: 'Uzvārds',
      email: 'E-pasts',
      phone: 'Telefona numurs',
      address: 'Adrese',
      preferredDate: 'Vēlamais datums',
      preferredTime: 'Vēlamais laiks',
      notes: 'Papildu piezīmes',
      submitButton: 'Pieteikties',
      serviceInfo: 'Pakalpojums pieejams Rīgā un apkārtnē • Sākot no €89',
      whatToExpect: 'Ko sagaidīt',
      expectations: [
        'Sertificēts flebotomists ieradīsies norādītajā laikā',
        'Profesionāla asins paņemšanas aprīkojums un drošības protokoli',
        'Rezultāti tiek apstrādāti CLIA sertificētā laboratorijā',
        'Digitālie rezultāti pieejami 24-48 stundu laikā'
      ],
      placeholders: {
        firstName: 'Ievadiet savu vārdu',
        lastName: 'Ievadiet savu uzvārdu',
        email: 'jūsu.epasts@piemērs.lv',
        phone: '+371 20 123 456',
        address: 'Ievadiet pilnu adresi',
        notes: 'Jebkādas īpašas instrukcijas vai veselības stāvokļi, par kuriem mums vajadzētu zināt...'
      }
    }
  };

  const currentText = text[language];

  return (
    <div className="relative overflow-hidden">
      {/* Main Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center">
          <div className="flex justify-center mb-6">
            <div className="bg-blue-100 p-4 rounded-full">
              <Activity className="h-12 w-12 text-blue-600" />
            </div>
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">
            Personalized Medicine Based <span className="block">on <span className="text-blue-600">Data</span></span>
          </h1>
          
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
            70% of medical decisions are based on laboratory tests
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <button
              onClick={onGetStarted}
              className="bg-blue-600 text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-700 transition-all duration-200 shadow-lg hover:shadow-xl flex items-center justify-center group"
            >
              Start Your Health Journey
              <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="border-2 border-gray-300 text-gray-700 px-8 py-4 rounded-lg font-semibold text-lg hover:border-blue-600 hover:text-blue-600 transition-all duration-200">
              Watch Demo
            </button>
          </div>

          {/* Trust Indicators */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-8 text-sm text-gray-600 mb-16">
            <div className="flex items-center">
              <Shield className="h-5 w-5 text-green-600 mr-2" />
              Encrypted Data
            </div>
            <div className="flex items-center">
              <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
              Certified Laboratory
            </div>
            <div className="flex items-center">
              <Users className="h-5 w-5 text-green-600 mr-2" />
              Licensed Physicians
            </div>
          </div>
        </div>

        {/* Lifespan Optimization Image */}
        <div className="flex justify-center mb-16">
          <img 
            src={language === 'en' ? "/src/l v h span 3 (1).jpg" : "/src/l v h span 4 (1).jpg"}
            alt={language === 'en' 
              ? "Health span optimization chart showing lifespan vs healthspan" 
              : "Veselības ilguma optimizācijas diagramma, kas parāda dzīves ilgumu pret veselības ilgumu"
            }
            className="max-w-4xl w-full h-auto rounded-xl shadow-lg"
          />
        </div>

        {/* Key Features Grid */}
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          <div className="bg-white p-8 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 group">
            <div className="bg-blue-100 p-3 rounded-lg w-fit mb-6 group-hover:bg-blue-200 transition-colors">
              <TrendingUp className="h-8 w-8 text-blue-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-4">Biological Age Analysis</h3>
            <p className="text-gray-600 leading-relaxed">
              Calculate your biological age using the open-source PhenoAge algorithm. 
              Track your aging speed and see how your lifestyle impacts longevity.
            </p>
          </div>

          <div className="bg-white p-8 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 group">
            <div className="bg-green-100 p-3 rounded-lg w-fit mb-6 group-hover:bg-green-200 transition-colors">
              <Activity className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-4">Nutrient Optimization</h3>
            <p className="text-gray-600 leading-relaxed">
              Identify vitamin and nutrient deficiencies from your lab results. 
              Get personalized supplement recommendations to optimize your health.
            </p>
          </div>

          <div className="bg-white p-8 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 group">
            <div className="bg-purple-100 p-3 rounded-lg w-fit mb-6 group-hover:bg-purple-200 transition-colors">
              <Users className="h-8 w-8 text-purple-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-4">Expert Consultations</h3>
            <p className="text-gray-600 leading-relaxed">
              Connect with certified nutritionists, fitness coaches, and licensed physicians 
              for personalized health programs and telemedicine consultations.
            </p>
          </div>
        </div>
      </div>

      {/* Scrolling Health Conditions Tags */}
      <div className="w-full pb-16">
        <div className="text-center mb-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            {language === 'en' ? 'Track early warning signs of 100+ health conditions' : 'Uzraugiet vairāk nekā 100+ slimību agrīnos rādītājus'}
          </h2>
          <p className="text-gray-600">
            {language === 'en' 
              ? 'Our platform helps track and optimize health for various conditions'
              : 'Mūsu platforma palīdz izsekot un optimizēt veselību dažādiem stāvokļiem'
            }
          </p>
        </div>
        
        <div className="relative overflow-hidden">
          <div className="flex animate-scroll hover:pause-animation">
            {/* First set of tags */}
            <div className="flex space-x-4 mr-4">
              {(language === 'en' ? [
                'Breast cysts', 'Diabetes', 'Ovarian cyst', 'Prostate cancer', 'Hyperthyroidism',
                'Anemia', 'Stroke', 'PCOS', 'Hepatitis', 'Fatty liver',
                'Aortic aneurysm', 'Brain aneurysm', 'Lupus', 'Hashimoto'
              ] : [
                'Krūts cistas', 'Diabēts', 'Olnīcu cistas', 'Prostatas vēzis', 'Hipertireoze',
                'Anēmija', 'Insults', 'PCOS', 'Hepatīts', 'Taukainā akna',
                'Aortas aneirisma', 'Smadzeņu aneirisma', 'Vilkēde', 'Hašimoto'
              ]).map((tag, index) => (
                <div
                  key={index}
                  className="flex-shrink-0 bg-blue-50 hover:bg-blue-100 border border-blue-200 hover:border-blue-300 px-12 py-6 rounded-full text-blue-800 font-medium text-2xl transition-all duration-300 hover:scale-105 hover:shadow-md cursor-pointer whitespace-nowrap"
                >
                  {tag}
                </div>
              ))}
            </div>
            
            {/* Duplicate set for seamless loop */}
            <div className="flex space-x-4">
              {(language === 'en' ? [
                'Breast cysts', 'Diabetes', 'Ovarian cyst', 'Prostate cancer', 'Hyperthyroidism',
                'Anemia', 'Stroke', 'PCOS', 'Hepatitis', 'Fatty liver',
                'Aortic aneurysm', 'Brain aneurysm', 'Lupus', 'Hashimoto'
              ] : [
                'Krūts cistas', 'Diabēts', 'Olnīcu cistas', 'Prostatas vēzis', 'Hipertireoze',
                'Anēmija', 'Insults', 'PCOS', 'Hepatīts', 'Taukainā akna',
                'Aortas aneirisma', 'Smadzeņu aneirisma', 'Vilkēde', 'Hašimoto'
              ]).map((tag, index) => (
                <div
                  key={`duplicate-${index}`}
                  className="flex-shrink-0 bg-blue-50 hover:bg-blue-100 border border-blue-200 hover:border-blue-300 px-12 py-6 rounded-full text-blue-800 font-medium text-2xl transition-all duration-300 hover:scale-105 hover:shadow-md cursor-pointer whitespace-nowrap"
                >
                  {tag}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Results Tracking Hero Section */}
      <div className="w-full bg-gradient-to-br from-blue-500 via-blue-600 to-indigo-600 py-20 relative overflow-hidden mb-16">
        {/* Background decorative elements */}
        <div className="absolute top-10 right-20 w-64 h-64 border border-white border-opacity-20 rounded-full"></div>
        <div className="absolute bottom-10 left-10 w-32 h-32 border border-white border-opacity-10 rounded-full"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left side - Text content */}
            <div className="text-white">
              <h2 className="text-5xl md:text-6xl font-bold mb-8 leading-tight">
                {language === 'en' ? (
                  <>
                    Results tracked<br />
                    <span className="text-white text-opacity-90">through every stage of life.</span>
                  </>
                ) : (
                  <>
                    Nepārtraukta veselības uzraudzība<br />
                    <span className="text-white text-opacity-90">katrā dzīves posmā.</span>
                  </>
                )}
              </h2>
              <p className="text-xl text-white text-opacity-90 leading-relaxed max-w-lg">
                {language === 'en' 
                  ? 'Always know how your body is changing. All results stored in one secure place for easy access anytime.'
                  : 'Vienmēr ziniet, kā mainās jūsu ķermenis. Visi rezultāti glabājas vienā drošā vietā ērtai piekļuvei jebkurā laikā.'
                }
              </p>
            </div>

            {/* Right side - Chart visualization */}
            <div className="relative">
              {/* Main chart container */}
              <div className="bg-gray-800 rounded-2xl p-8 shadow-2xl relative">
                {/* Chart area */}
                <div className="h-48 relative mb-6">
                  <ChartVisualization language={language} />
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>

      {/* MOS SF-36 Health Questionnaire Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20 pt-16">
        <div className="relative bg-gradient-to-br from-green-50 to-emerald-100 rounded-2xl shadow-xl border border-green-200 overflow-hidden max-w-3xl mx-auto">
          {/* Background Image */}
          <div className="absolute inset-0 opacity-10">
            <img 
              src="/output.png" 
              alt="SF-36 Health Domains Chart" 
              className="w-full h-full object-contain"
            />
          </div>
          
          {/* Content overlay */}
          <div className="relative z-10">
            <div className="text-center py-8 px-8">
              <div className="mb-6">
                <h2 className="text-4xl font-bold text-gray-900 mb-4">
                  {language === 'en' ? (
                    <>Free Online Health <span className="text-green-600">Questionnaire</span></>
                  ) : (
                    <>Bezmaksas tiešsaistes veselības <span className="text-green-600">anketa</span></>
                  )}
                </h2>
                <p className="text-xl text-gray-700 max-w-3xl mx-auto mb-6">
                  {language === 'en' 
                    ? 'Discover your health status and quality of life with the SF-36 Health Questionnaire Survey.'
                    : 'Atklājiet savu veselības stāvokli un dzīves kvalitāti ar SF-36 veselības anketas aptauju.'
                  }
                </p>
              </div>

              {/* Health Score Visualization */}
              <div className="relative mb-8">
                <div className="w-48 h-48 mx-auto relative">
                  {/* Circular Progress Background */}
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                    <circle
                      cx="50"
                      cy="50"
                      r="45"
                      stroke="rgba(34, 197, 94, 0.2)"
                      strokeWidth="8"
                      fill="none"
                    />
                    <circle
                      cx="50"
                      cy="50"
                      r="45"
                      stroke="rgb(34, 197, 94)"
                      strokeWidth="8"
                      fill="none"
                      strokeDasharray="283"
                      strokeDashoffset="85"
                      strokeLinecap="round"
                      className="transition-all duration-1000 ease-out"
                    />
                  </svg>
                  
                  {/* Center Content */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-green-600 mb-1">SF-36</div>
                      <div className="text-sm text-gray-600">
                        {language === 'en' ? 'Health Survey' : 'Veselības aptauja'}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Benefits Grid */}
              <div className="grid md:grid-cols-3 gap-6 mb-8 max-w-4xl mx-auto">
                <div className="bg-white p-6 rounded-xl shadow-md border border-green-100">
                  <div className="bg-green-100 p-3 rounded-lg w-fit mx-auto mb-4">
                    <TrendingUp className="h-6 w-6 text-green-600" />
                  </div>
                  <h3 className="font-bold text-gray-900 mb-2">
                    {language === 'en' ? 'Health Overview' : 'Veselības pārskats'}
                  </h3>
                  <p className="text-gray-600 text-sm">
                    {language === 'en' 
                      ? 'Get comprehensive insights into your physical and mental health status'
                      : 'Iegūstiet visaptverošu ieskatu savā fiziskajā un garīgajā veselības stāvoklī'
                    }
                  </p>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-md border border-green-100">
                  <div className="bg-blue-100 p-3 rounded-lg w-fit mx-auto mb-4">
                    <Users className="h-6 w-6 text-blue-600" />
                  </div>
                  <h3 className="font-bold text-gray-900 mb-2">
                    {language === 'en' ? 'Population Comparison' : 'Salīdzinājums ar populāciju'}
                  </h3>
                  <p className="text-gray-600 text-sm">
                    {language === 'en' 
                      ? 'See how your health metrics compare to others in your age group'
                      : 'Redziet, kā jūsu veselības rādītāji salīdzinās ar citiem jūsu vecuma grupā'
                    }
                  </p>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-md border border-green-100">
                  <div className="bg-purple-100 p-3 rounded-lg w-fit mx-auto mb-4">
                    <CheckCircle className="h-6 w-6 text-purple-600" />
                  </div>
                  <h3 className="font-bold text-gray-900 mb-2">
                    {language === 'en' ? 'Personalized Insights' : 'Personalizēti ieskati'}
                  </h3>
                  <p className="text-gray-600 text-sm">
                    {language === 'en' 
                      ? 'Receive tailored recommendations to improve your quality of life'
                      : 'Saņemiet pielāgotus ieteikumus dzīves kvalitātes uzlabošanai'
                    }
                  </p>
                </div>
              </div>

              {/* CTA Button */}
              <button className="bg-gradient-to-r from-green-600 to-emerald-600 text-white px-6 py-3 rounded-xl font-semibold text-lg hover:from-green-700 hover:to-emerald-700 transition-all duration-200 shadow-lg hover:shadow-xl flex items-center justify-center mx-auto group">
                <Activity className="mr-3 h-6 w-6 group-hover:scale-110 transition-transform" />
                {language === 'en' ? 'Get My Overall Health Status' : 'Iegūt manu vispārējo veselības stāvokli'}
                <ArrowRight className="ml-3 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </button>
              
              <p className="text-sm text-gray-600 mt-3">
                {language === 'en' 
                  ? '7-10 minute questionnaire • Scientifically validated • Instant results'
                  : '7-10 minūšu anketa • Zinātniski apstiprināta • Tūlītēji rezultāti'
                }
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Biomarkers Scrolling Tags Section */}
      <div className="w-full pb-16">
        <div className="text-center mb-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            {language === 'en' ? 'In-Depth Biomarker Testing' : 'Dziļa biomarķieru testēšana'}
          </h2>
          <p className="text-gray-600">
            {language === 'en' 
              ? 'We analyze a broad spectrum of biomarkers to help you understand your health status'
              : 'Mēs analizējam plašu biomarķieru spektru, lai palīdzētu jums saprast savu veselības stāvokli'
            }
          </p>
        </div>
        
        <div className="relative overflow-hidden">
          <div className="flex animate-scroll hover:pause-animation">
            {/* First set of biomarker tags */}
            <div className="flex space-x-4 mr-4">
              {(language === 'en' ? [
                'Fasting Glucose', 'HbA1c', 'Total Cholesterol', 'ALAT/ASAT', 'Albumin',
                'Red Blood Cells', 'White Blood Cells', 'Thrombocytes', 'Alkaline Phosphatase',
                'Magnesium', 'Calcium', 'Zinc', 'Iron', 'Ferritin',
                'Testosterone', 'Estrogen', 'Cortisol', 'Hemoglobin'
              ] : [
                'Tukšā dūšā glikoze', 'HbA1c', 'Kopējais holesterīns', 'ALAT/ASAT', 'Albumīns',
                'Sarkanie asins šūnu', 'Baltie asins šūnu', 'Trombocīti', 'Sārmainā fosfatāze',
                'Magnijs', 'Kalcijs', 'Cinks', 'Dzelzs', 'Feritīns',
                'Testosterons', 'Estrogens', 'Kortizols', 'Hemoglobīns'
              ]).map((biomarker, index) => (
                <div
                  key={index}
                  className="flex-shrink-0 bg-green-50 hover:bg-green-100 border border-green-200 hover:border-green-300 px-12 py-6 rounded-full text-green-800 font-medium text-2xl transition-all duration-300 hover:scale-105 hover:shadow-md cursor-pointer whitespace-nowrap"
                >
                  {biomarker}
                </div>
              ))}
            </div>
            
            {/* Duplicate set for seamless loop */}
            <div className="flex space-x-4">
              {(language === 'en' ? [
                'Fasting Glucose', 'HbA1c', 'Total Cholesterol', 'ALAT/ASAT', 'Albumin',
                'Red Blood Cells', 'White Blood Cells', 'Thrombocytes', 'Alkaline Phosphatase',
                'Magnesium', 'Calcium', 'Zinc', 'Iron', 'Ferritin',
                'Testosterone', 'Estrogen', 'Cortisol', 'Hemoglobin'
              ] : [
                'Tukšā dūšā glikoze', 'HbA1c', 'Kopējais holesterīns', 'ALAT/ASAT', 'Albumīns',
                'Sarkanie asins šūnu', 'Baltie asins šūnu', 'Trombocīti', 'Sārmainā fosfatāze',
                'Magnijs', 'Kalcijs', 'Cinks', 'Dzelzs', 'Feritīns',
                'Testosterons', 'Estrogens', 'Kortizols', 'Hemoglobīns'
              ]).map((biomarker, index) => (
                <div
                  key={`duplicate-${index}`}
                  className="flex-shrink-0 bg-green-50 hover:bg-green-100 border border-green-200 hover:border-green-300 px-12 py-6 rounded-full text-green-800 font-medium text-2xl transition-all duration-300 hover:scale-105 hover:shadow-md cursor-pointer whitespace-nowrap"
                >
                  {biomarker}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* FAQ Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-8">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Left Side - Description */}
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                {language === 'en' ? "Some questions we've heard before" : "Daži jautājumi, ko esam dzirdējuši agrāk"}
              </h2>
              <p className="text-gray-600 mb-8">
                {language === 'en' 
                  ? "Not seeing your question here? Check our full FAQ page or contact us."
                  : "Neredzat savu jautājumu šeit? Pārbaudiet mūsu pilno BUJ lapu vai sazinieties ar mums."
                }
              </p>
              
              <div className="space-y-4">
                <button className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors flex items-center">
                  <span>{language === 'en' ? 'View full FAQs' : 'Skatīt visus BUJ'}</span>
                  <svg className="ml-2 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </button>
                <button className="border border-gray-300 text-gray-700 px-6 py-3 rounded-lg font-semibold hover:bg-gray-50 transition-colors">
                  {language === 'en' ? 'Contact us' : 'Sazinieties ar mums'}
                </button>
              </div>
            </div>

            {/* Right Side - Q&A */}
            <div className="space-y-4">
              {faqData.map((faq, index) => (
                <div key={index} className="border border-gray-200 rounded-xl overflow-hidden">
                  <button
                    onClick={() => setOpenFaq(openFaq === index ? null : index)}
                    className="w-full px-6 py-4 text-left bg-gray-50 hover:bg-gray-100 transition-colors flex items-center justify-between"
                  >
                    <span className="font-semibold text-gray-900">{faq.question}</span>
                    <svg 
                      className={`h-5 w-5 text-gray-500 transition-transform duration-200 ${openFaq === index ? 'rotate-180' : ''}`}
                      fill="none" 
                      stroke="currentColor" 
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                  {openFaq === index && (
                    <div className="px-6 py-4 bg-white border-t border-gray-200">
                      <p className="text-gray-700 leading-relaxed">{faq.answer}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Biological Age Report Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        <div className="bg-gradient-to-r from-blue-500 to-cyan-400 rounded-2xl shadow-2xl overflow-hidden">
          {/* Header with user info and action buttons */}
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                  <User className="h-8 w-8 text-white" />
                </div>
                <div className="text-white">
                  <h2 className="text-3xl font-bold">
                    {language === 'en' ? 'Jānis Kalniņš' : 'Jānis Kalniņš'}
                  </h2>
                  <p className="text-xl">
                    {language === 'en' ? '42 years • Last analysis: 15.01.2024' : '42 gadi • Pēdējā analīze: 15.01.2024'}
                  </p>
                </div>
              </div>
              <div className="flex space-x-3">
                <button className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white px-4 py-2 rounded-lg font-semibold transition-all duration-200 flex items-center">
                  <ArrowRight className="h-6 w-6 mr-2" />
                  <span className="text-lg">{language === 'en' ? 'Export' : 'Eksportēt'}</span>
                </button>
                <button className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white px-4 py-2 rounded-lg font-semibold transition-all duration-200 flex items-center">
                  <Users className="h-6 w-6 mr-2" />
                  <span className="text-lg">{language === 'en' ? 'Share' : 'Dalīties'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Main content area */}
          <div className="bg-white p-6">
            <div className="grid lg:grid-cols-3 gap-4">
              {/* Biological Age Section */}
              <div className="lg:col-span-2">
                <div className="bg-gradient-to-br from-green-50 to-emerald-100 border border-green-200 rounded-2xl p-4">
                  <div className="flex items-center mb-3">
                    <div className="bg-green-500 text-white px-3 py-1 rounded-full font-semibold flex items-center">
                      <CheckCircle className="h-6 w-6 mr-1" />
                      <span className="text-lg">{language === 'en' ? 'Optimal' : 'Optimāli'}</span>
                    </div>
                  </div>
                  
                  <h3 className="text-3xl font-bold text-gray-900 mb-4">
                    {language === 'en' ? 'Biological Age' : 'Bioloģiskais vecums'}
                  </h3>

                  <div className="grid grid-cols-3 gap-4 mb-4">
                    {/* Your Biological Age */}
                    <div className="text-center">
                      <div className="text-lg text-gray-600 mb-1">
                        {language === 'en' ? 'Your biological age' : 'Jūsu bioloģiskais vecums'}
                      </div>
                      <div className="text-6xl font-bold text-green-600 mb-1">36.5</div>
                      <div className="text-lg text-gray-600">
                        {language === 'en' ? 'years' : 'gadi'}
                      </div>
                    </div>

                    {/* Chronological Age */}
                    <div className="text-center">
                      <div className="text-lg text-gray-600 mb-1">
                        {language === 'en' ? 'Chronological age' : 'Hronoloģiskais vecums'}
                      </div>
                      <div className="text-6xl font-bold text-gray-700 mb-1">42</div>
                      <div className="text-lg text-gray-600">
                        {language === 'en' ? 'years' : 'gadi'}
                      </div>
                    </div>

                    {/* Age Difference */}
                    <div className="text-center">
                      <div className="text-lg text-gray-600 mb-1">
                        {language === 'en' ? 'Difference' : 'Atšķirība'}
                      </div>
                      <div className="text-6xl font-bold text-green-600 mb-1">-5.5</div>
                      <div className="text-lg text-gray-600">
                        {language === 'en' ? 'years' : 'gadi'}
                      </div>
                    </div>
                  </div>

                  <div className="bg-white border border-green-200 rounded-xl p-3">
                    <p className="text-gray-800 text-xl leading-relaxed">
                      {language === 'en' 
                        ? 'You are biologically younger than your chronological age. Continue healthy lifestyle!'
                        : 'Jūs esat bioloģiski jaunāks par savu hronoloģisko vecumu. Turpiniet veselīgu dzīvesveidu!'
                      }
                    </p>
                  </div>
                </div>
              </div>

              {/* Health Score Section */}
              <div className="bg-gradient-to-br from-blue-50 to-indigo-100 border border-blue-200 rounded-2xl p-4">
                <h3 className="text-3xl font-bold text-gray-900 mb-4 text-center">
                  {language === 'en' ? 'Health Score' : 'Veselības rādītājs'}
                </h3>

                {/* Circular Progress */}
                <div className="relative w-32 h-32 mx-auto mb-4">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                    {/* Background circle */}
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      stroke="rgba(59, 130, 246, 0.2)"
                      strokeWidth="8"
                      fill="none"
                    />
                    {/* Progress circle */}
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      stroke="rgb(16, 185, 129)"
                      strokeWidth="8"
                      fill="none"
                      strokeDasharray="251.2"
                      strokeDashoffset="50.24"
                      strokeLinecap="round"
                      className="transition-all duration-1000 ease-out"
                    />
                  </svg>
                  
                  {/* Center content */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-4xl font-bold text-green-600 mb-1">85</div>
                      <div className="text-lg text-gray-600">
                        {language === 'en' ? 'points' : 'punkti'}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="text-center">
                  <div className="text-xl font-semibold text-gray-900 mb-1">
                    {language === 'en' ? 'Excellent health condition' : 'Lielisks veselības stāvoklis'}
                  </div>
                  <p className="text-gray-600 text-lg">
                    {language === 'en' 
                      ? 'Your health metrics indicate optimal wellness'
                      : 'Jūsu veselības rādītāji norāda uz optimālu labsajūtu'
                    }
                  </p>
                </div>
              </div>
            </div>

            {/* Bottom action section */}
            <div className="mt-6 pt-6 border-t border-gray-200">
              <div className="flex flex-col sm:flex-row items-center justify-between">
                <div className="text-center sm:text-left mb-4 sm:mb-0">
                  <h4 className="text-xl font-semibold text-gray-900 mb-1">
                    {language === 'en' ? 'Ready to optimize further?' : 'Gatavs optimizēt vēl vairāk?'}
                  </h4>
                  <p className="text-gray-600 text-lg">
                    {language === 'en' 
                      ? 'Get personalized recommendations to maintain your excellent health'
                      : 'Saņemiet personalizētus ieteikumus, lai saglabātu savu lielisko veselību'
                    }
                  </p>
                </div>
                <div className="flex space-x-4">
                  <button className="bg-blue-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors flex items-center text-sm">
                    <TrendingUp className="h-6 w-6 mr-1" />
                    <span className="text-lg">{language === 'en' ? 'View Recommendations' : 'Skatīt ieteikumus'}</span>
                  </button>
                  <button className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg font-semibold hover:bg-gray-50 transition-colors flex items-center text-sm">
                    <Calendar className="h-6 w-6 mr-1" />
                    <span className="text-lg">{language === 'en' ? 'Schedule Follow-up' : 'Plānot turpinājumu'}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Home Visit Reservation Form */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden">
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-8 py-6">
            <div className="flex items-center justify-center mb-4">
              <div className="bg-white bg-opacity-20 p-3 rounded-full mr-4">
                <MapPin className="h-8 w-8 text-white" />
              </div>
              <div className="text-center">
                <h2 className="text-2xl font-bold text-white mb-2">{currentText.title}</h2>
                <p className="text-blue-100">{currentText.subtitle}</p>
              </div>
            </div>
          </div>

          <div className="p-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-2">{currentText.firstName}</label>
                  <input
                    type="text"
                    id="firstName"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleInputChange}
                    placeholder={currentText.placeholders.firstName}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-gray-50 hover:bg-white"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-2">{currentText.lastName}</label>
                  <input
                    type="text"
                    id="lastName"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleInputChange}
                    placeholder={currentText.placeholders.lastName}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-gray-50 hover:bg-white"
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">{currentText.email}</label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder={currentText.placeholders.email}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-gray-50 hover:bg-white"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">{currentText.phone}</label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    placeholder={currentText.placeholders.phone}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-gray-50 hover:bg-white"
                    required
                  />
                </div>
              </div>

              <div>
                <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-2">{currentText.address}</label>
                <input
                  type="text"
                  id="address"
                  name="address"
                  value={formData.address}
                  onChange={handleInputChange}
                  placeholder={currentText.placeholders.address}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-gray-50 hover:bg-white"
                  required
                />
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="preferredDate" className="block text-sm font-medium text-gray-700 mb-2">
                    <Calendar className="h-4 w-4 inline mr-1" />
                    {currentText.preferredDate}
                  </label>
                  <input
                    type="date"
                    id="preferredDate"
                    name="preferredDate"
                    value={formData.preferredDate}
                    onChange={handleInputChange}
                    min={new Date().toISOString().split('T')[0]}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-gray-50 hover:bg-white"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="preferredTime" className="block text-sm font-medium text-gray-700 mb-2">
                    <Clock className="h-4 w-4 inline mr-1" />
                    {currentText.preferredTime}
                  </label>
                  <select
                    id="preferredTime"
                    name="preferredTime"
                    value={formData.preferredTime}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-gray-50 hover:bg-white"
                    required
                  >
                    <option value="">{language === 'en' ? 'Select time slot' : 'Izvēlieties laiku'}</option>
                    <option value="08:00-10:00">08:00 - 10:00</option>
                    <option value="10:00-12:00">10:00 - 12:00</option>
                    <option value="12:00-14:00">12:00 - 14:00</option>
                    <option value="14:00-16:00">14:00 - 16:00</option>
                    <option value="16:00-18:00">16:00 - 18:00</option>
                  </select>
                </div>
              </div>

              <div>
                <label htmlFor="notes" className="block text-sm font-medium text-gray-700 mb-2">{currentText.notes}</label>
                <textarea
                  id="notes"
                  name="notes"
                  value={formData.notes}
                  onChange={handleInputChange}
                  rows={4}
                  placeholder={currentText.placeholders.notes}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 bg-gray-50 hover:bg-white resize-none"
                />
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
                <div className="flex items-start">
                  <Shield className="h-6 w-6 text-blue-600 mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-blue-900 mb-2">{currentText.whatToExpect}</h4>
                    <ul className="text-sm text-blue-800 space-y-1">
                      {currentText.expectations.map((expectation, idx) => (
                        <li key={idx}>• {expectation}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              <div className="text-center">
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <button
                    type="submit"
                    className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-8 py-4 rounded-lg font-semibold text-lg hover:from-blue-700 hover:to-indigo-700 transition-all duration-200 shadow-lg hover:shadow-xl flex items-center justify-center group"
                  >
                    <MapPin className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform" />
                    {currentText.submitButton}
                    <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                  </button>
                  
                  <button
                    type="button"
                    className="bg-white border-2 border-blue-600 text-blue-600 px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-50 transition-all duration-200 shadow-lg hover:shadow-xl flex items-center justify-center group"
                  >
                    <MapPin className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform" />
                    {language === 'en' ? 'Find a Service Center' : 'Atrast servisa centru'}
                    <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
                <p className="text-sm text-gray-600 mt-4">
                  {currentText.serviceInfo}
                </p>
              </div>
            </form>
          </div>
        </div>
      </div>

      {/* Background Elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10">
        <div className="absolute top-20 left-10 w-72 h-72 bg-blue-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse"></div>
        <div className="absolute top-40 right-10 w-96 h-96 bg-purple-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse animation-delay-2000"></div>
        <div className="absolute bottom-20 left-20 w-80 h-80 bg-green-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse animation-delay-4000"></div>
      </div>
    </div>
  );
}

interface FAQItemProps {
  question: string;
  answer: string;
  language: 'en' | 'lv';
}

function FAQItem({ question, answer }: FAQItemProps) {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <div className="border border-gray-200 rounded-xl overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full px-6 py-4 text-left bg-gray-50 hover:bg-gray-100 transition-colors flex items-center justify-between"
      >
        <span className="font-semibold text-gray-900 text-lg">{question}</span>
        <div className={`transform transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`}>
          <svg className="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </div>
      </button>
      {isOpen && (
        <div className="px-6 py-4 bg-white border-t border-gray-200">
          <p className="text-gray-700 leading-relaxed">{answer}</p>
        </div>
      )}
    </div>
  );
}

function ChartVisualization({ language }: { language: 'en' | 'lv' }) {
  const [currentYear, setCurrentYear] = React.useState(0); // 0=2024, 1=2025, 2=2026
  const years = ['2024', '2025', '2026'];
  const cholesterolValues = [6.5, 5.1, 4.2];
  const improvementPercentages = [0, 25, 35]; // Improvement percentages for each year
  
  // Calculate data point positions based on cholesterol values
  const getDataPointY = (value: number) => {
    // Map cholesterol values (6.5 to 4.2) to Y coordinates (40 to 120)
    const minValue = 4.2;
    const maxValue = 6.5;
    const minY = 40;
    const maxY = 120;
    return minY + ((maxValue - value) / (maxValue - minValue)) * (maxY - minY);
  };

  React.useEffect(() => {
    const interval = setInterval(() => {
      setCurrentYear(prev => (prev + 1) % 3);
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <>
      {/* Cholesterol metric card */}
      <div className="absolute -top-4 -right-4 bg-gradient-to-br from-yellow-200 to-yellow-300 rounded-xl p-4 shadow-lg animate-pulse">
        <div className="text-center">
          <div className="text-sm text-gray-600 font-medium mb-1">
            {language === 'en' ? 'Total Cholesterol' : 'Kopējais holesterīns'}
          </div>
          <div className="text-3xl font-bold text-orange-600 mb-1 transition-all duration-1000">
            {cholesterolValues[currentYear]}
          </div>
          <div className="text-xs text-gray-500">mmol/L</div>
          <div className="text-xs text-gray-500 mt-1">
            {improvementPercentages[currentYear] > 0 && (
              <span className="text-green-600 font-medium">
                -{improvementPercentages[currentYear]}% improvement
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Y-axis labels */}
      <div className="absolute left-0 top-0 h-full flex flex-col justify-between text-xs text-gray-400">
        <span>6.0</span>
        <span>5.0</span>
        <span>4.0</span>
        <span>3.0</span>
      </div>

      {/* Chart line */}
      <div className="ml-8 h-full relative">
        <svg className="w-full h-full" viewBox="0 0 300 180">
          {/* Grid lines */}
          <defs>
            <pattern id="grid" width="60" height="45" patternUnits="userSpaceOnUse">
              <path d="M 60 0 L 0 0 0 45" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="1"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
          
          {/* Cholesterol trend line */}
          <path
            d={`M 20 ${getDataPointY(6.5)} Q 150 ${getDataPointY(5.1)} 280 ${getDataPointY(4.2)}`}
            fill="none"
            stroke="rgba(34, 197, 94, 0.8)"
            strokeWidth="3"
            strokeLinecap="round"
            strokeDasharray="400"
            strokeDashoffset="400"
            className="animate-draw-line"
          />
          
          {/* Data points */}
          <circle 
            cx="20" 
            cy={getDataPointY(6.5)} 
            r="4" 
            fill="white" 
            stroke="rgb(34, 197, 94)" 
            strokeWidth="2" 
            className={`transition-all duration-1000 ${currentYear >= 0 ? 'opacity-100' : 'opacity-30'}`}
          />
          <circle 
            cx="150" 
            cy={getDataPointY(5.1)} 
            r="4" 
            fill="white" 
            stroke="rgb(34, 197, 94)" 
            strokeWidth="2" 
            className={`transition-all duration-1000 ${currentYear >= 1 ? 'opacity-100' : 'opacity-30'}`}
          />
          <circle 
            cx="280" 
            cy={getDataPointY(4.2)} 
            r="4" 
            fill="white" 
            stroke="rgb(34, 197, 94)" 
            strokeWidth="2" 
            className={`transition-all duration-1000 ${currentYear >= 2 ? 'opacity-100' : 'opacity-30'}`}
          />
        </svg>
      </div>

      {/* X-axis years */}
      <div className="flex justify-between text-sm text-gray-400 ml-8 mt-4">
        <span className={`px-3 py-1 rounded-full text-xs font-medium transition-all duration-1000 ${
          currentYear === 0 ? 'bg-blue-500 text-white' : 'opacity-50'
        }`}>2024</span>
        <span className={`px-3 py-1 rounded-full text-xs font-medium transition-all duration-1000 ${
          currentYear === 1 ? 'bg-blue-500 text-white' : 'opacity-50'
        }`}>2025</span>
        <span className={`px-3 py-1 rounded-full text-xs font-medium transition-all duration-1000 ${
          currentYear === 2 ? 'bg-blue-500 text-white' : 'opacity-50'
        }`}>2026</span>
      </div>

      {/* Additional floating metrics */}
      <div className="absolute -bottom-6 -left-6 bg-white rounded-xl p-4 shadow-lg">
        <div className="text-center">
          <div className="text-xs text-gray-500 mb-1">
            {language === 'en' ? 'Improvement' : 'Uzlabojums'}
          </div>
          <div className="text-lg font-bold text-green-600 transition-all duration-1000">
            {improvementPercentages[currentYear] > 0 ? `-${improvementPercentages[currentYear]}%` : 'Baseline'}
          </div>
        </div>
      </div>
    </>
  );
}