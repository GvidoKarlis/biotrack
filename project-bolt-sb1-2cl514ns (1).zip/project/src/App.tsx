import React, { useState } from 'react';
import { Navigation } from './components/Navigation';
import { Hero } from './components/Hero';
import { Dashboard } from './components/Dashboard';
import { LabUpload } from './components/LabUpload';
import { HealthPackages } from './components/HealthPackages';
import { ConsultationBooking } from './components/ConsultationBooking';
import { ProgressTracking } from './components/ProgressTracking';

function App() {
  const [activeSection, setActiveSection] = useState('hero');
  const [language, setLanguage] = useState<'en' | 'lv'>('en');

  const renderSection = () => {
    switch (activeSection) {
      case 'dashboard':
        return <Dashboard />;
      case 'lab-upload':
        return <LabUpload onComplete={() => setActiveSection('dashboard')} />;
      case 'packages':
        return <HealthPackages />;
      case 'consultations':
        return <ConsultationBooking />;
      case 'progress':
        return <ProgressTracking />;
      default:
        return <Hero onGetStarted={() => setActiveSection('dashboard')} language={language} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <Navigation 
        activeSection={activeSection} 
        onSectionChange={setActiveSection} 
        language={language}
        onLanguageChange={setLanguage}
      />
      {renderSection()}
    </div>
  );
}

export default App;